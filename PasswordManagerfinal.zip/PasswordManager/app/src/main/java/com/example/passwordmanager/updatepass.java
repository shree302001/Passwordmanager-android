package com.example.passwordmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class updatepass extends AppCompatActivity {
    Button saveu;
    EditText newpass,webu;
    DBhelper dBhelper;
    Intent ran,homm,urown,del,ret,upda,vie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatepass);
        newpass=findViewById(R.id.newpass);
        webu=findViewById(R.id.webu);
        saveu=findViewById(R.id.saveu);
        dBhelper=new DBhelper(this);
        saveu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if(newpass.getText().toString().equals("")||webu.getText().toString().equals(""))
                Toast.makeText(updatepass.this,"Please enter both details", Toast.LENGTH_SHORT).show();
            else
            {
                String webs=webu.getText().toString().toLowerCase(Locale.ROOT);
                String passu=newpass.getText().toString();

           Boolean checkudeletedata = dBhelper.deleteuserdata(webs);
                if (checkudeletedata == true)
                {
                    Boolean checkinsertdata = dBhelper.insertuserdata(webs, passu);
                    if (checkinsertdata == true)
                    {    Toast.makeText(updatepass.this, "Update Successfull", Toast.LENGTH_SHORT).show();

                    }
                    else
                        Toast.makeText(updatepass.this, "Update failed", Toast.LENGTH_SHORT).show();

                }
                else
                    Toast.makeText(updatepass.this, "Update failed", Toast.LENGTH_SHORT).show();


            }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionsmenufromupdatepass,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.rando) {
            ran=new Intent(updatepass.this,random.class);
            startActivity(ran);
        }
        if(id==R.id.hom)
        {
            homm=new Intent(updatepass.this,MainActivity.class);
            startActivity(homm);
        }
        if(id==R.id.retreiv)
        {
            ret=new Intent(updatepass.this,retreivepass.class);
            startActivity(ret);
        }
        if(id==R.id.delet)
        {
            del=new Intent(updatepass.this,deletepass.class);
            startActivity(del);
        }

        if(id==R.id.viewa) {
            Intent vie=new Intent(updatepass.this,viewallpass.class);
            startActivity(vie);
        }
        if(id==R.id.creat)
        {
            Intent gen=new Intent(updatepass.this,createurownn.class);
            startActivity(gen);
        }
        return super.onOptionsItemSelected(item);
    }
}