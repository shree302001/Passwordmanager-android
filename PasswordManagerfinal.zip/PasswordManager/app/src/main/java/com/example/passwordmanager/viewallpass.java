package com.example.passwordmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class viewallpass extends AppCompatActivity {
Button viewal;
    Intent ran,homm,urown,del,ret,upda,vie;
DBhelper dBhelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewallpass);
        viewal=findViewById(R.id.viewal);
        dBhelper=new DBhelper(this);
        viewal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = dBhelper.getdata();
                if (res.getCount()==0){
                    Toast.makeText(viewallpass.this,"no entry exists",Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer= new StringBuffer();
                while (res.moveToNext()){
                    buffer.append("Website :"+res.getString(0)+"\n");
                    buffer.append("Password:"+res.getString(1)+"\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(viewallpass.this);
                builder.setCancelable(true);
                builder.setTitle("user Entries");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionsmenuforviewall,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.rando) {
            ran=new Intent(viewallpass.this,random.class);
            startActivity(ran);
        }
        if(id==R.id.hom)
        {
            homm=new Intent(viewallpass.this,MainActivity.class);
            startActivity(homm);
        }
        if(id==R.id.retreiv)
        {
            ret=new Intent(viewallpass.this,retreivepass.class);
            startActivity(ret);
        }
        if(id==R.id.delet)
        {
            del=new Intent(viewallpass.this,deletepass.class);
            startActivity(del);
        }

        if(id==R.id.updat) {
            Intent vie=new Intent(viewallpass.this,updatepass.class);
            startActivity(vie);
        }
        if(id==R.id.creat)
        {
            Intent gen=new Intent(viewallpass.this,createurownn.class);
            startActivity(gen);
        }
        return super.onOptionsItemSelected(item);
    }
}