package com.example.passwordmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    Button create,delete,generate,retreive,update,viewall;
    Intent ran,hom,urown,del,ret,upda,vie;
    VideoView vw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        create=findViewById(R.id.create);
        delete=findViewById(R.id.delete);
        generate=findViewById(R.id.generate);
        retreive=findViewById(R.id.retreive);
        update=findViewById(R.id.update);
        viewall=findViewById(R.id.viewall);
        create.setBackgroundColor(Color.rgb(24,172,236));

        delete.setHighlightColor(Color.rgb(24,172,236));
        generate.setBackgroundColor(Color.rgb(24,172,236));
        retreive.setBackgroundColor(Color.rgb(24,172,236));
        update.setBackgroundColor(Color.rgb(24,172,236));
        viewall.setBackgroundColor(Color.rgb(24,172,236));
        del=new Intent(MainActivity.this,deletepass.class);
        ran=new Intent(MainActivity.this,random.class);
        urown=new Intent(MainActivity.this,createurownn.class);
        ret=new Intent(MainActivity.this,retreivepass.class);
        upda=new Intent(MainActivity.this,updatepass.class);
        vie=new Intent(MainActivity.this,viewallpass.class);
        getSupportActionBar().hide();
        generate.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(ran);
             }
         });
         create.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(urown);
             }
         });
         retreive.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(ret);
             }
         });
         delete.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(del);
             }
         });
         update.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(upda);

             }
         });
         viewall.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(vie);
             }
         });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionsmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.rando)
            startActivity(ran);
        if(id==R.id.creat)
            startActivity(urown);
        if(id==R.id.retreiv)
        {
            startActivity(ret);
        }
        if(id==R.id.delet)
        {
            startActivity(del);
        }
        if(id==R.id.updat)
        {
            startActivity(upda);
        }
        if(id==R.id.viewa)
            startActivity(vie);
        return super.onOptionsItemSelected(item);
    }
}